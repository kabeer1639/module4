﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using LICEntity;
using LICException;

namespace LICDataAccessLayer {
    public class LICDAL {
        public bool AddLicDAL(LICEntities newLic) {
            bool licAdded = false;
            //try {
                DbCommand command = LICDataConnection.CreateCommand();
                command.CommandText = "AddCustomer";

                DbParameter param = command.CreateParameter();
                param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = newLic.CUSTOMERNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@DOB";
                param.DbType = DbType.DateTime;
                param.Value = newLic.DOB;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Address";
                param.DbType = DbType.String;
                param.Value = newLic.ADDRESS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@PolicyName";
                param.DbType = DbType.String;
                param.Value = newLic.POLICYNAME;
                command.Parameters.Add(param);

                //param = command.CreateParameter();
                //param.ParameterName = "@PolicyID";
                //param.DbType = DbType.Int32;
                //param.Value = newLic.POLICYID;
                //command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@BranchName";
                param.DbType = DbType.String;
                param.Value = newLic.BRANCHNAME;
                command.Parameters.Add(param);

                //param = command.CreateParameter();
                //param.ParameterName = "@BranchID";
                //param.DbType = DbType.Int32;
                //param.Value = newLic.BRANCHID;
                //command.Parameters.Add(param);

            int affectedRows = LICDataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0) {
                    licAdded = true;
                }
            //}
            //catch(Exception ex) {
            //    throw new LICIException(ex.Message);
            //}
            return licAdded;
        }

        public List<LICEntities> GetAllLicDAL() {
            List<LICEntities> licList = null;
            try {
                DbCommand command = LICDataConnection.CreateCommand();
                command.CommandText = "GetAllPolicies";

                DataTable dataTable = LICDataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0) {
                    licList = new List<LICEntities>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++) {
                        LICEntities lic = new LICEntities();
                        lic.POLICYID = (int)dataTable.Rows[rowCounter][0];
                        lic.POLICYNAME= (string)dataTable.Rows[rowCounter][1];
                        licList.Add(lic);
                    }
                }
            } catch (DbException ex) {
                throw new LICIException(ex.Message);
            }
            return licList;
        }

        public LICEntities SearchCustDAL(int searchCustID) {
            LICEntities searchCust = null;
            try {
                DbCommand command = LICDataConnection.CreateCommand();
                command.CommandText = "SearchCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.Int32;
                param.Value = searchCustID;
                command.Parameters.Add(param);

                DataTable dataTable = LICDataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0) {
                    searchCust = new LICEntities();
                    searchCust.CUSTOMERID = (int)dataTable.Rows[0][0];
                    searchCust.POLICYNAME = (string)dataTable.Rows[0][1];
                    searchCust.BRANCHNAME = (string)dataTable.Rows[0][2];
                }
            } catch (DbException ex) {
                throw new LICIException(ex.Message);
            }
            return searchCust;
        }
    }
}
