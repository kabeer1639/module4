﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace LICDataAccessLayer {
    class LICDataConfiguration {
        private static string providerName;
        public static string PROVIDERNAME {
            get { return LICDataConfiguration.providerName; }
            set { LICDataConfiguration.providerName = value; }
        }

        private static string connectionString;
        public static string CONNECTIONSTRING {
            get { return LICDataConfiguration.connectionString; }
            set { LICDataConfiguration.connectionString = value; }
        }
        public LICDataConfiguration() {
            providerName = ConfigurationManager.ConnectionStrings["licConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["licConnection"].ConnectionString;
        }
    }
}
