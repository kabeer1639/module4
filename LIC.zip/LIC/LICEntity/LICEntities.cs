﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICEntity
{
    public class LICEntities
    {
        public int CUSTOMERID { get; set; }
        public string CUSTOMERNAME { get; set; }
        public DateTime DOB { get; set; }
        public string ADDRESS { get; set; }
        public string BRANCHNAME { get; set; }
        public string POLICYNAME { get; set; }
        public int POLICYID { get; set; }
        public int BRANCHID { get; set; }
    }
}
