﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using LICDataAccessLayer;
using LICEntity;
using LICException;

namespace LICBusinessAccessLayer {
    public class LICBAL {
        public static bool AddLicBL(LICEntities newLic) {
            bool licAdded = false;
            LICDAL licDAL = new LICDAL();
            licAdded = licDAL.AddLicDAL(newLic);
            return licAdded;
        }

        public static List<LICEntities> GetAllPoliciesBL() {
            List<LICEntities> licList = null;
            try {
                LICDAL licDAL = new LICDAL();
                licList = licDAL.GetAllLicDAL();
            } catch (LICIException ex) {
                throw ex;
            } catch (Exception ex) {
                throw ex;
            }
            return licList;
        }

        public static LICEntities SearchCustBL(int searchCustID) {
            LICEntities searchCust = null;
            try {
                LICDAL custDAL = new LICDAL();
                searchCust = custDAL.SearchCustDAL(searchCustID);
            } catch (LICIException ex) {
                throw ex;
            } catch (Exception ex) {
                throw ex;
            }
            return searchCust;

        }
    }
}
