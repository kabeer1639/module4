﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICException
{
    public class LICIException:ApplicationException
    {
        public LICIException() : base()
        {

        }
        public LICIException(string message):base(message)
        {

        }
        public LICIException(string message, Exception innerException):base(message,innerException)
        {

        }
    }
}
