﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LICBusinessAccessLayer;
using LICEntity;
using LICException;

namespace LICLogin {
    public partial class UserInfo : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected void Button1_Click(object sender, EventArgs e) {
            // try {
            //string name = txtcustname.Text;
            //DateTime dob = Convert.ToDateTime(dob1.SelectedDate);
            //string add = txtcustadd.Text;
            //int bid = Convert.ToInt32(DropDownList1.SelectedItem.Text);
            //int pid= Convert.ToInt32(DropDownList2.SelectedItem.Text);
            ////string dadm = dateofadm.SelectedDate.Value.ToShortDateString();
            //LICEntities lic = new LICEntities();
            //lic.CUSTOMERNAME= name;
            //lic.DOB = dob;
            //lic.ADDRESS= add;
            //lic.BRANCHID = bid;
            //lic.POLICYID = pid;
            //LICBAL.AddLicBL(lic);
            bool licAdded = LICBAL.AddLicBL(new LICEntities {
                CUSTOMERNAME = txtcustname.Text,
                DOB = Convert.ToDateTime(dob1.SelectedDate),
                ADDRESS = txtcustadd.Text,
                BRANCHNAME = DropDownList1.SelectedItem.Text,
                POLICYNAME=DropDownList2.SelectedItem.Text
            });
            if (licAdded) {
                Label4.Text = "Customer Added";
            } else {
                Label4.Text = "Some Problem is occured";
            }
            //} catch (LICIException ex) {
            //    ex.ToString();
            //}
        }

        protected void Button3_Click(object sender, EventArgs e) {
            Response.Redirect("WebForm2.aspx");
        }
    }
}