﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace LICLogin {
    public partial class WebForm1 : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected void Button1_Click(object sender, EventArgs e) {
            if(TextBox1.Text=="admin" && TextBox2.Text=="admin123") {
                FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, false);
                //Response.Redirect("~/UserInfo.aspx");
            } else {
                Label3.Text = "Please Enter Correct Username and Password";
            }
        }
    }
}