create database lic

use lic

create table Policy (PolicyID int primary key identity(101,1),PolicyName varchar(30),Duration int,PremiumAmt decimal,MaturityAmt decimal);

create table Branches (BranchID int primary key identity(1,1),BranchName varchar(20),BranchAddress varchar(50));

create table Customer (CustomerID int primary key identity(1,1),CustomerName varchar(20),DOB date,Address varchar(50));

create table CustomerPolicy (CustomerID int,PolicyName varchar(30),BranchName varchar(20),foreign key(CustomerID) references Customer(CustomerID));

drop table CustomerPolicy;

insert into Policy values('Life',10,5000,500000);
insert into Policy values('Medical',5,1000,100000);
insert into Policy values('Vehicle',1,8000,200000);
select * from Policy;

insert into Branches values('Naranpura','Ahmedabad');
insert into Branches values('Whitefield','Bangalore');
insert into Branches values('Andheri','Mumbai');
select * from Branches;

insert into Customer values('Jay','12/12/2017','Mumbai');
insert into Customer values('Parth','11/12/2017','Pune');
select * from Customer;


--Procedure to insert the data
Go
alter Procedure AddCustomer (
	@CustomerName varchar(50),
	@DOB DateTime,
	@Address varchar(50),
	@PolicyName varchar(30),
	@BranchName varchar(20)
)
As
Begin
	Insert into Customer values (
		@CustomerName,
		@DOB,
		@Address
	)
	Declare @ID int
	Select @ID = max(CustomerID) from Customer;
	Insert into CustomerPolicy values (
		@ID,
		@PolicyName,
		@BranchName
	)
End

Go
Create Procedure GetAllPolicies
As
Begin
	Select PolicyID,PolicyName from Policy
End

CREATE PROCEDURE [dbo].[SearchCustomer] 
	
	(
	@CustomerID int
	
	)
	
AS
		select CustomerID,PolicyName,BranchName from CustomerPolicy where CustomerID = @CustomerID;
	RETURN