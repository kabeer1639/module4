﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace StudentAdmissionDAL
{
    class StudentConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return StudentConfiguration.providerName; }
            set { StudentConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return StudentConfiguration.connectionString; }
            set { StudentConfiguration.connectionString = value; }
        }

        static StudentConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["StudentCon"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["StudentCon"].ConnectionString;
        }

    }
}
