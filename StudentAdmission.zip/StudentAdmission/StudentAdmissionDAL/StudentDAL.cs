﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data.Common;
using System.Data;

namespace StudentAdmissionDAL
{
    public class StudentDAL
    {
        public List<string> mGetAllCities()
        {
            List<string> cities = null;

            DbCommand command = DataConnection.CreateCommand();
            command.CommandText = "GetAllCities";



            DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {
                cities = new List<string>();
                for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                {
                    Student stud = new Student();
                    stud.City = (string)dataTable.Rows[rowCounter][0];
                    cities.Add(stud.City);
                }
            }


            return cities;
        }
        public List<string> mGetAllCourses()
        {
            List<string> courses = null;

            DbCommand command = DataConnection.CreateCommand();
            command.CommandText = "GetAllCourses";



            DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {
                courses = new List<String>();
                for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                {
                    Student stud = new Student();
                    stud.City = (string)dataTable.Rows[rowCounter][0];
                    courses.Add(stud.City);
                }

            }
            return courses;

        }

        public static Student SearchStudentDAL(string studentName)
        {
            Student searchStudent = null;


            DbCommand command = DataConnection.CreateCommand();
            command.CommandText = "SearchStudent";

            DbParameter param = command.CreateParameter();
            param.ParameterName = "@StudentName";
            param.DbType = DbType.Int32;
            param.Value = studentName;
            command.Parameters.Add(param);

            DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
            if (dataTable.Rows.Count > 0)
            {
                searchStudent = new Student();
                searchStudent.StudentName = (string)dataTable.Rows[0][0];
                searchStudent.DOB = (DateTime)dataTable.Rows[0][1];
                //searchStudent.City = (string)dataTable.Rows[0][2];
                searchStudent.CourseName = (string)dataTable.Rows[0][2];
                searchStudent.AdmissionDate = (DateTime)dataTable.Rows[0][3];

            }


            return searchStudent;
        }


        public string mRegistration(Student obj)
        {
            DbCommand cmd = DataConnection.CreateCommand();
            cmd.CommandText = "Register";

            DbParameter param = cmd.CreateParameter();
            param.ParameterName = "@StudentName";
            param.DbType = DbType.String;
            param.Value = obj.StudentName; ;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@DOB";
            param.DbType = DbType.DateTime;
            param.Value = obj.DOB;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@City";
            param.DbType = DbType.String;
            param.Value = obj.City;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@CourseName";
            param.DbType = DbType.String;
            param.Value = obj.CourseName;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@AdmisionDate";
            param.DbType = DbType.DateTime;
            param.Value = obj.AdmissionDate;
            cmd.Parameters.Add(param);


            DataTable dataTable = DataConnection.ExecuteSelectCommand(cmd);
            if (dataTable.Rows.Count > 0)
            {
                return "Details not added";
            }


            else
                return "Details added";
        }
    }
}
