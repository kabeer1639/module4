﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using StudentAdmissionDAL;

namespace StudentAdmissionBL
{
    public class StudentBL
    {
        public static List<String> mGetAllCities()
        {
            List<string> cities = null;
            StudentDAL obj1 = new StudentDAL();
            cities = obj1.mGetAllCities();
            return cities;
        }
        public static List<String> mGetAllCourses()
        {
            List<string> courses = null;
            StudentDAL obj1 = new StudentDAL();
            courses = obj1.mGetAllCourses();
            return courses;
        }

        public static string mRegistration(Student obj)
        {
            StudentDAL dalobj = new StudentDAL();
            return dalobj.mRegistration(obj);
        }
    }
}
