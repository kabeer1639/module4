﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entities;
using StudentAdmissionBL;

namespace StudentAdmission
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<string> cities = new List<string>();
            cities = StudentBL.mGetAllCities();

            //cityList.AppendDataBoundItems = true;
            foreach (string item in cities)
            {
                cityList.Items.Add(item.ToString());
            }

            List<string> courses = new List<string>();
            courses = StudentBL.mGetAllCourses();

            foreach(string item in courses)
            {
                courseList.Items.Add(item.ToString());
            }

        }

        protected void regBtn_Click(object sender, EventArgs e)
        {
            Student obj = new Student();
            obj.StudentName = txtName.Text;
            obj.DOB = Convert.ToDateTime( txtDOB.Text);
            obj.City = cityList.SelectedItem.Text;
            obj.CourseName = courseList.SelectedItem.Text;
            obj.AdmissionDate = Convert.ToDateTime(txtAdmDate.Text);

            string message = StudentBL.mRegistration(obj);
            Label1.Text = message;
        }
    }
}