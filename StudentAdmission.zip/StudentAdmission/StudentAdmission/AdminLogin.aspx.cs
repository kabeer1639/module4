﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentAdmission
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           

            if (TextBox1.Text == "apurv" && TextBox2.Text == "123")
            {
                Response.Redirect("Registration.aspx");
            }
            else
            {
                Label1.Text = "Please Enter the correct login Credentials";
            }
        }
    }
}