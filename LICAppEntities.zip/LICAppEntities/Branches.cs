﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICAppEntities
{
   public class Branches
    {
        public int BRANCHID { get; set; }
        public string BRANCHNAME { get; set; }
        public string BRANCHADDRESS { get; set; }
    }
}
