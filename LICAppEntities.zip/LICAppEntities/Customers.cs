﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICAppEntities
{
   public class Customers
    {
        public int CUSTID { get; set; }
        public string CUSTNAME { get; set; }
        public DateTime CUSTDOB { get; set; }
        public string ADDRESS { get; set; }
        public int POLICYID { get; set; }
        public int BRANCHID { get; set; }
    }
}
