﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICAppEntities
{
    public class Policy
    {
        public int POLICYID { get; set; }
        public string POLICYNAME { get; set; }
        public int DURATION{ get; set; }
        public double PREMIUMAMT { get; set; }
        public double MATURITYAMT { get; set; }
    }
}
