﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using OYODAL;

namespace OYOBAL
{
    public class BL
    {
        public static string mBooking(OYO obj)
        {
            DAL dalobj = new DAL();
            return dalobj.mBooking(obj);
        }
    }
}
