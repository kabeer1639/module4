﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class OYO
    {
        public int HotelId { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }

        public string IdDoc { get; set; }

        public DateTime DateIn { get; set; }
        public DateTime DateOut { get; set; }

        public string RoomType { get; set; }
    }
}
