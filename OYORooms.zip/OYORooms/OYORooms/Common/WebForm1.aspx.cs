﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace OYORooms
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            if (TextBox1.Text == "mohit" && TextBox2.Text == "123")
            {
                FormsAuthentication.RedirectFromLoginPage("Booking.aspx",false);
            }
            else
            {
                Label3.Text = "Please Enter the correct login Credentials";
            }
        }
    }
}