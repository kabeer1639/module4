﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OYOBAL;
using Entities;

namespace OYORooms
{
    public partial class Booking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            OYO obj = new OYO();
            obj.HotelId = Convert.ToInt32( DropDownList1.SelectedItem.Text);
            obj.CustomerName = custName.Text;
            obj.Address = custAddress.Text;
            obj.IdDoc = DropDownList2.SelectedItem.Text;
            obj.DateIn = Calendar1.SelectedDate;
            obj.DateOut = Calendar2.SelectedDate;
            obj.RoomType = DropDownList3.SelectedItem.Text;

            string message = BL.mBooking(obj);


            addLabel.Text = message;

            int charges;

            if (DropDownList3.SelectedItem.Text == "AC")
            {
                charges = 2000;
            }

            else charges = 1000;
           
                int bill = Convert.ToInt32((obj.DateOut - obj.DateIn).TotalDays) * charges;

                BillLabel.Text = "Your Bill is" + bill.ToString();
            
        }
    }
}