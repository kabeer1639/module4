﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace OYODAL
{
    class OYOConfiguration
    {

        private static string providerName;

        public static string ProviderName
        {
            get { return OYOConfiguration.providerName; }
            set { OYOConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return OYOConfiguration.connectionString; }
            set { OYOConfiguration.connectionString = value; }
        }

        static OYOConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["OYO"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["OYO"].ConnectionString;
        }

    }
}
