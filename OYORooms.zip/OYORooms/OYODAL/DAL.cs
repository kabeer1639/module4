﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data;
using System.Data.Common;

namespace OYODAL
{
    public class DAL
    {
        public string mBooking(OYO obj)
        {
            DbCommand cmd = DataConnection.CreateCommand();
            cmd.CommandText = "doBooking";

            DbParameter param = cmd.CreateParameter();
            param.ParameterName = "@HotelId";
            param.DbType = DbType.Int32;
            param.Value = obj.HotelId;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@CustomerName";
            param.DbType = DbType.String;
            param.Value = obj.CustomerName ;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@Address";
            param.DbType = DbType.String;
            param.Value = obj.Address;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@IdDoc";
            param.DbType = DbType.String;
            param.Value = obj.IdDoc;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@DateIn";
            param.DbType = DbType.DateTime;
            param.Value = obj.DateIn;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@DateOut";
            param.DbType = DbType.DateTime;
            param.Value = obj.DateOut;
            cmd.Parameters.Add(param);

            param = cmd.CreateParameter();
            param.ParameterName = "@RoomType";
            param.DbType = DbType.String;
            param.Value = obj.RoomType;
            cmd.Parameters.Add(param);

            DataTable dataTable = DataConnection.ExecuteSelectCommand(cmd);
            if (dataTable.Rows.Count > 0)
            {
                return "Details not added";
            }


            else
                return "Details added";
        }
    }
    }
