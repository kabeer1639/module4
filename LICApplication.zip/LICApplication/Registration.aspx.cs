﻿using System;
using System.Collections.Generic;
using LICAppBAL;
using LICAppEntities;
using LICAppExceptions;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LICApplication
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lbMessage.Text = "";
            if (!Page.IsPostBack)
            {
                try
                {
                    List<Policy> plist = LICBAL.GetPolicyName();
                    dlPolicy.Items.Add("Select a Policy");
                    dlPolicy.AppendDataBoundItems = true;
                   
                    dlPolicy.DataSource = plist;
                    
                    dlPolicy.DataTextField ="POLICYNAME";
                    dlPolicy.DataValueField = "POLICYID";
                    dlPolicy.DataBind();
                    //foreach (Policy p in plist)
                    //{
                    //    dlPolicy.Items.Add(p.POLICYNAME);
                    //}

                    List<Branches> blist = LICBAL.GetBranchName();
                    dlBranch.Items.Add("Select a Branch");
                    dlBranch.AppendDataBoundItems = true;

                    dlBranch.DataSource = blist;
                    dlBranch.DataTextField = "BRANCHNAME";
                    dlBranch.DataValueField = "BRANCHID";
                    dlBranch.DataBind();
                    //foreach (Branches b in blist)
                    //{
                    //    dlBranch.Items.Add(b.BRANCHNAME);
                    //}
                }
                catch
                {

                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Customers newcm = new Customers();

               
                newcm.CUSTNAME = tbName.Text;
                newcm.CUSTDOB = cldob.SelectedDate;
                newcm.ADDRESS = tbAddress.Text;
                newcm.POLICYID = Convert.ToInt32( dlPolicy.SelectedItem.Value);
                newcm.BRANCHID = Convert.ToInt32(dlBranch.SelectedItem.Value);
                bool cmAdded = LICBAL.AddCustomers(newcm);
                if (cmAdded)
                {
                    lbMessage.Text = "Customer Added Successfully";

                }

                else
                    lbMessage.Text = "Customer can not be Added";

            }
            catch (LICExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}