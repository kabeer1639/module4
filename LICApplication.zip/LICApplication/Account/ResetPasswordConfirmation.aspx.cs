﻿using System.Web.UI;

namespace LICApplication.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}