﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class Day1 : System.Web.UI.Page
    {
        List<GST> gst = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            //if(!Page.IsPostBack)
            //{
            //   Label1.Text = "Before going to server";
            //}
            //else
            //{
            //    Label1.Text = "Info from server";
            //}

          
            if (!Page.IsPostBack)
            {


                gst = new List<GST>
                {
                    new GST { SlabName="Food Items",TaxableRate=5},
                    new GST { SlabName="Electronics Items",TaxableRate=12},
                    new GST { SlabName="Automobiles Items",TaxableRate=18},
                };
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add(new ListItem("--Select a Slab--", "0"));
                DropDownList1.AppendDataBoundItems = true;
                DropDownList1.DataSource = gst;

                DropDownList1.DataTextField = "SlabName";
                DropDownList1.DataValueField = "TaxableRate";

                DropDownList1.DataBind();


            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(DropDownList1.SelectedItem.Value) > 0 && DropDownList2.SelectedIndex > 0)
            {
                //Label1.Text = "Welcome to ASP.NET";
                double taxrate = Convert.ToDouble(DropDownList1.SelectedItem.Value);
                double gstAmount = 0.0;
                gstAmount = ((Convert.ToDouble(TextBox1.Text) * taxrate) / 100) + (Convert.ToDouble(TextBox1.Text));
                //Label1.Text = gstAmount.ToString();

                Label1.Text = DropDownList2.SelectedItem.Text
                    + "(" + DropDownList1.SelectedItem.Text + ") purchased for amount -"
                    + gstAmount.ToString();
            

        }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           // Label1.Text = DropDownList1.Text + "-" + DropDownList1.SelectedItem;
            switch (Convert.ToInt32(DropDownList1.SelectedItem.Value))
            {
                case 12:

                    DropDownList2.Items.Add("LED TV");
                    DropDownList2.Items.Add("Laptop");
                    DropDownList2.Items.Add("Mobile");
                    break;


                case 5:

                    DropDownList2.Items.Add("Pizza");
                    DropDownList2.Items.Add("Burger");
                    DropDownList2.Items.Add("Coffee");
                    break;


                case 18:

                    DropDownList2.Items.Add("Car");
                    DropDownList2.Items.Add("Bike");

                    break;



            }


        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("WebForm2.aspx?prod" + DropDownList2.SelectedItem.Text +
                "&Email=" + TextBox2.Text);
               
        }
    }

    class GST
    {
        public string SlabName { get; set; }
        public int TaxableRate { get; set; }
    }
}