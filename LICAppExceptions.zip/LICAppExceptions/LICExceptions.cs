﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LICAppExceptions
{
    public class LICExceptions:ApplicationException
    {
        public LICExceptions():base()
        {

        }

        public LICExceptions(string Message):base(Message)
        {

        }

        public LICExceptions(string message,Exception innerException):base(message,innerException)
        {

        }
    }
}
