﻿using System;
using System.Collections.Generic;
using LICAppEntities;
using LICAppDAL;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LICAppExceptions;

namespace LICAppBAL
{
    public class LICBAL
    {
        //method to find Policy name
        public static List<Policy> GetPolicyName()
        {
            List<Policy> pList = null;
            try
            {
                LICDAL pDal = new LICDAL();
                pList = pDal.GetPolicyName();
            }
            catch (LICExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return pList;
        }

        public static List<Branches> GetBranchName()
        {
            List<Branches> bList = null;
            try
            {
                LICDAL bDal = new LICDAL();
                bList = bDal.GetBranchName();
            }
            catch (LICExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bList;
        }

        public static bool AddCustomers(Customers newcm)
        {
            bool cmAdded = false;
            try
            {


                LICDAL cmDAL = new LICDAL();
                cmAdded = cmDAL.AddCustomers(newcm);

            }
            catch (LICExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return cmAdded;
        }
    }
}
